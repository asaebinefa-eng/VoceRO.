package com.vocero.app.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder

/**
 * Captură audio brută de la microfon, la 16 kHz mono PCM-16 — formatul exact
 * cerut de Whisper (rata lui de eșantionare este fixă, prin construcție).
 */
class MicRecorder {
    private var audioRecord: AudioRecord? = null

    // Permisiunea RECORD_AUDIO este verificată de apelant (MainActivity) înainte
    // de a chema start(); adnotarea de mai jos doar oprește avertismentul lintului.
    @SuppressLint("MissingPermission")
    fun start(): Boolean {
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuf <= 0) return false

        val recorder = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            minBuf * 2
        )

        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            recorder.release()
            return false
        }

        recorder.startRecording()
        audioRecord = recorder
        return true
    }

    /** Citește un bloc de eșantioane. Întoarce numărul citit, sau <= 0 dacă nu sunt date. */
    fun readChunk(buffer: ShortArray): Int {
        return audioRecord?.read(buffer, 0, buffer.size) ?: -1
    }

    fun stop() {
        audioRecord?.let {
            try {
                it.stop()
            } catch (_: IllegalStateException) {
                // era deja oprit — nu e o problemă
            }
            it.release()
        }
        audioRecord = null
    }

    companion object {
        const val SAMPLE_RATE = 16000
    }
}
