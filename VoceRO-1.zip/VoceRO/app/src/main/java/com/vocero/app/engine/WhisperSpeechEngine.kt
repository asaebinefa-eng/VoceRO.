package com.vocero.app.engine

import com.vocero.app.audio.MicRecorder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

/**
 * Motor de recunoaștere vocală bazat pe whisper.cpp, rulat 100% pe dispozitiv,
 * fără nicio conexiune la internet.
 *
 * IMPORTANT despre "live": spre deosebire de Vosk/Kaldi, Whisper nu este prin
 * construcție un model de streaming — el transcrie un bloc de audio dintr-o
 * dată. "Live"-ul din această aplicație este simulat printr-o fereastră
 * glisantă:
 *   1) Se captează audio continuu de la microfon (fire separat, nu se blochează).
 *   2) La fiecare ~2 secunde, dacă utilizatorul încă vorbește, se rulează din
 *      nou Whisper pe ce s-a acumulat până acum și se afișează rezultatul ca
 *      text "provizoriu" (poate să se mai schimbe).
 *   3) Când se detectează o pauză de vorbire (~0.9s de tăcere), rezultatul se
 *      "fixează" (final), bufferul se golește și începe un segment nou.
 *
 * Pe un Kirin 810 (Huawei P40 Lite) cu modelul "tiny" te poți aștepta la o
 * întârziere de ordinul secundelor, nu instantanee ca la un asistent cloud.
 * Vezi README.md pentru cum poți ajusta acest compromis.
 */
class WhisperSpeechEngine(
    private val modelPath: String,
    private val numThreads: Int = 4
) : SpeechEngine {

    override var listener: SpeechEngine.Listener? = null

    private val mic = MicRecorder()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var captureJob: Job? = null
    private var processJob: Job? = null

    private var contextPtr: Long = 0L
    private val bufferLock = Any()
    private val sampleBuffer = ArrayList<Float>()

    @Volatile private var silenceMs = 0
    @Volatile private var running = false
    @Volatile private var confirmedText = ""

    /** Încarcă modelul nativ. Se apelează o singură dată, pe un fir de fundal. */
    fun loadModel(): Boolean {
        contextPtr = WhisperBridge.initContext(modelPath)
        return contextPtr != 0L
    }

    override fun start() {
        if (running) return
        if (contextPtr == 0L) {
            listener?.onError("Modelul de recunoaștere vocală nu este încărcat.")
            return
        }
        if (!mic.start()) {
            listener?.onError("Nu s-a putut porni microfonul.")
            return
        }

        running = true
        confirmedText = ""
        silenceMs = 0
        synchronized(bufferLock) { sampleBuffer.clear() }
        listener?.onMicStateChanged(true)

        captureJob = scope.launch { captureLoop() }
        processJob = scope.launch { processLoop() }
    }

    /** Fir 1: golește microfonul cât mai des posibil — NU trebuie să aștepte niciodată Whisper. */
    private suspend fun captureLoop() {
        val shortBuf = ShortArray(CHUNK_SAMPLES)
        while (isActive && running) {
            val n = mic.readChunk(shortBuf)
            if (n > 0) {
                var energySum = 0.0
                val floats = FloatArray(n)
                for (i in 0 until n) {
                    val f = shortBuf[i] / 32768f
                    floats[i] = f
                    energySum += abs(f)
                }
                silenceMs = if (energySum / n < SILENCE_THRESHOLD) silenceMs + CHUNK_MS else 0
                synchronized(bufferLock) {
                    for (f in floats) sampleBuffer.add(f)
                }
            }
        }
    }

    /** Fir 2: la interval, ia o "poză" a bufferului și rulează Whisper (poate dura câteva secunde). */
    private suspend fun processLoop() {
        var lastProcess = System.currentTimeMillis()
        while (isActive && running) {
            delay(POLL_INTERVAL_MS)

            val bufferedCount = synchronized(bufferLock) { sampleBuffer.size }
            val bufferedMs = bufferedCount * 1000L / MicRecorder.SAMPLE_RATE
            val now = System.currentTimeMillis()

            val shouldFinalize = silenceMs >= SILENCE_TO_FINALIZE_MS && bufferedMs > MIN_SEGMENT_MS
            val shouldForce = bufferedMs > MAX_SEGMENT_MS
            val shouldPartial = !shouldFinalize && !shouldForce &&
                bufferedMs > MIN_SEGMENT_MS && (now - lastProcess) > PARTIAL_INTERVAL_MS

            if (!shouldFinalize && !shouldForce && !shouldPartial) continue

            val snapshot = synchronized(bufferLock) { sampleBuffer.toFloatArray() }
            val text = WhisperBridge.transcribe(contextPtr, snapshot, numThreads, LANGUAGE, confirmedText)
            lastProcess = System.currentTimeMillis()

            if (shouldFinalize || shouldForce) {
                if (text.isNotBlank()) {
                    confirmedText = (confirmedText + " " + text).trim()
                    withContext(Dispatchers.Main) { listener?.onFinalResult(text.trim()) }
                }
                synchronized(bufferLock) { sampleBuffer.clear() }
                silenceMs = 0
            } else if (text.isNotBlank()) {
                withContext(Dispatchers.Main) { listener?.onPartialResult(text.trim()) }
            }
        }
    }

    override fun stop() {
        if (!running) return
        running = false
        captureJob?.cancel()
        processJob?.cancel()
        mic.stop()
        listener?.onMicStateChanged(false)
    }

    override fun release() {
        stop()
        if (contextPtr != 0L) {
            WhisperBridge.freeContext(contextPtr)
            contextPtr = 0L
        }
    }

    companion object {
        private const val LANGUAGE = "ro"

        private const val CHUNK_MS = 100
        private const val CHUNK_SAMPLES = MicRecorder.SAMPLE_RATE * CHUNK_MS / 1000 // 1600 eșantioane

        private const val POLL_INTERVAL_MS = 200L
        private const val SILENCE_THRESHOLD = 0.015
        private const val SILENCE_TO_FINALIZE_MS = 900
        private const val MIN_SEGMENT_MS = 600
        private const val PARTIAL_INTERVAL_MS = 2000L
        private const val MAX_SEGMENT_MS = 12000L
    }
}
