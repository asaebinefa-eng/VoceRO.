package com.vocero.app.engine

/**
 * Contract generic pentru un motor de recunoaștere vocală live.
 *
 * Interfața este intenționat independentă de Whisper: dacă în viitor apare un
 * model mai potrivit pentru română (sau unul mai rapid pe Huawei), este
 * suficient să implementezi din nou această interfață — restul aplicației
 * (MainActivity, autosave, export) nu se schimbă deloc.
 */
interface SpeechEngine {
    var listener: Listener?

    /** Pornește ascultarea continuă a microfonului. */
    fun start()

    /** Oprește ascultarea; textul acumulat până acum rămâne neatins. */
    fun stop()

    /** Eliberează resursele native. Se apelează la închiderea aplicației. */
    fun release()

    interface Listener {
        /** Text "provizoriu", încă neconfirmat — se poate schimba la următoarea actualizare. */
        fun onPartialResult(text: String)

        /** Text "definitivat" — se adaugă permanent la transcriere. */
        fun onFinalResult(text: String)

        /** Anunță schimbarea stării microfonului, pentru indicatorul vizual din UI. */
        fun onMicStateChanged(active: Boolean)

        /** Eroare de afișat utilizatorului (permisiune, model lipsă, etc). */
        fun onError(message: String)
    }
}
