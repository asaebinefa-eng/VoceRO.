package com.vocero.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.Spannable
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.vocero.app.engine.ModelManager
import com.vocero.app.engine.SpeechEngine
import com.vocero.app.engine.WhisperSpeechEngine
import com.vocero.app.util.PdfExporter
import com.vocero.app.util.TranscriptStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity(), SpeechEngine.Listener {

    private lateinit var transcriptEdit: EditText
    private lateinit var micIcon: ImageView
    private lateinit var micLabel: TextView
    private lateinit var btnStart: MaterialButton
    private lateinit var btnStop: MaterialButton
    private lateinit var btnClear: MaterialButton
    private lateinit var btnCopy: MaterialButton

    private lateinit var store: TranscriptStore
    private var engine: WhisperSpeechEngine? = null

    /** Indexul din text de unde începe porțiunea "provizorie" (încă neconfirmată). -1 = nu există. */
    private var partialStart = -1
    private var modelReady = false

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            engine?.start()
        } else {
            Toast.makeText(this, getString(R.string.toast_permission_denied), Toast.LENGTH_LONG).show()
        }
    }

    private val createTxtLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri: Uri? -> uri?.let(::exportTxt) }

    private val createPdfLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri: Uri? -> uri?.let(::exportPdf) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setSupportActionBar(findViewById<MaterialToolbar>(R.id.toolbar))

        transcriptEdit = findViewById(R.id.transcriptEdit)
        micIcon = findViewById(R.id.micIcon)
        micLabel = findViewById(R.id.micLabel)
        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)
        btnClear = findViewById(R.id.btnClear)
        btnCopy = findViewById(R.id.btnCopy)

        store = TranscriptStore(this)
        transcriptEdit.setText(store.load())
        transcriptEdit.setSelection(transcriptEdit.text.length)

        setMicState(false)
        btnStop.isEnabled = false

        btnStart.setOnClickListener { onStartClicked() }
        btnStop.setOnClickListener { engine?.stop() }
        btnClear.setOnClickListener { confirmClear() }
        btnCopy.setOnClickListener { copyText() }

        initEngine()
    }

    /** Încarcă modelul Whisper pe un fir de fundal, o singură dată la pornirea aplicației. */
    private fun initEngine() {
        btnStart.isEnabled = false
        btnStart.text = getString(R.string.btn_loading)

        lifecycleScope.launch {
            val path = withContext(Dispatchers.IO) { ModelManager.ensureModel(applicationContext) }
            if (path == null) {
                onModelLoadFailed()
                return@launch
            }

            val newEngine = WhisperSpeechEngine(path)
            val loaded = withContext(Dispatchers.IO) { newEngine.loadModel() }

            if (!loaded) {
                onModelLoadFailed()
                return@launch
            }

            newEngine.listener = this@MainActivity
            engine = newEngine
            modelReady = true
            btnStart.text = getString(R.string.btn_start)
            btnStart.isEnabled = true
        }
    }

    private fun onModelLoadFailed() {
        Toast.makeText(this, getString(R.string.toast_model_missing), Toast.LENGTH_LONG).show()
        btnStart.text = getString(R.string.btn_start)
        btnStart.isEnabled = false
        modelReady = false
    }

    private fun onStartClicked() {
        if (!modelReady) return
        when {
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED -> engine?.start()
            else -> requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    // ---------------------------------------------------------------------
    // SpeechEngine.Listener — toate callback-urile pot veni de pe un fir de
    // fundal, de aceea folosim runOnUiThread înainte de a atinge view-urile.
    // ---------------------------------------------------------------------

    override fun onPartialResult(text: String) {
        runOnUiThread { updatePartial(text) }
    }

    override fun onFinalResult(text: String) {
        runOnUiThread { commitFinal(text) }
    }

    override fun onMicStateChanged(active: Boolean) {
        runOnUiThread { setMicState(active) }
    }

    override fun onError(message: String) {
        runOnUiThread { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }
    }

    // ---------------------------------------------------------------------
    // UI helpers
    // ---------------------------------------------------------------------

    private fun setMicState(active: Boolean) {
        btnStart.isEnabled = !active && modelReady
        btnStop.isEnabled = active
        micLabel.text = if (active) getString(R.string.mic_active) else getString(R.string.mic_inactive)
        micIcon.setImageResource(if (active) R.drawable.ic_mic_on else R.drawable.ic_mic_off)

        micIcon.clearAnimation()
        micIcon.alpha = 1f
        if (active) pulseMicIcon()
    }

    private fun pulseMicIcon() {
        micIcon.animate().alpha(0.35f).setDuration(700).withEndAction {
            if (btnStop.isEnabled) {
                micIcon.animate().alpha(1f).setDuration(700).withEndAction { pulseMicIcon() }.start()
            }
        }.start()
    }

    /** Afișează textul "provizoriu" curent, cu stil distinct (italic, gri) până se confirmă. */
    private fun updatePartial(text: String) {
        val editable = transcriptEdit.text
        if (partialStart == -1) {
            if (editable.isNotEmpty() && editable.last() != '\n' && editable.last() != ' ') {
                editable.append(' ')
            }
            partialStart = editable.length
        }
        editable.delete(partialStart, editable.length)
        val start = editable.length
        editable.append(text)
        editable.setSpan(StyleSpan(Typeface.ITALIC), start, editable.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        editable.setSpan(
            ForegroundColorSpan(ContextCompat.getColor(this, R.color.partial_text)),
            start, editable.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        transcriptEdit.setSelection(editable.length)
    }

    /** "Fixează" textul provizoriu ca text definitiv și salvează automat. */
    private fun commitFinal(text: String) {
        val editable = transcriptEdit.text
        if (partialStart != -1) {
            editable.delete(partialStart, editable.length)
            partialStart = -1
        }
        if (editable.isNotEmpty() && editable.last() != '\n' && editable.last() != ' ') {
            editable.append(' ')
        }
        editable.append(text)
        transcriptEdit.setSelection(editable.length)
        store.save(editable.toString())
    }

    private fun confirmClear() {
        AlertDialog.Builder(this)
            .setTitle(R.string.dialog_clear_title)
            .setMessage(R.string.dialog_clear_message)
            .setPositiveButton(R.string.dialog_clear_confirm) { _, _ ->
                transcriptEdit.setText("")
                partialStart = -1
                store.save("")
            }
            .setNegativeButton(R.string.dialog_clear_cancel, null)
            .show()
    }

    private fun copyText() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Transcriere VoceRO", transcriptEdit.text.toString()))
        Toast.makeText(this, getString(R.string.toast_copied), Toast.LENGTH_SHORT).show()
    }

    private fun timestampedName(extension: String): String {
        val sdf = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
        return "transcriere_${sdf.format(Date())}.$extension"
    }

    private fun exportTxt(uri: Uri) {
        try {
            contentResolver.openOutputStream(uri)?.use {
                it.write(transcriptEdit.text.toString().toByteArray())
            }
            Toast.makeText(this, getString(R.string.toast_export_success), Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, getString(R.string.toast_export_error), Toast.LENGTH_SHORT).show()
        }
    }

    private fun exportPdf(uri: Uri) {
        try {
            contentResolver.openOutputStream(uri)?.use { stream ->
                PdfExporter.createPdf(transcriptEdit.text.toString(), stream)
            }
            Toast.makeText(this, getString(R.string.toast_export_success), Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, getString(R.string.toast_export_error), Toast.LENGTH_SHORT).show()
        }
    }

    private fun toggleTheme() {
        val newMode = if (AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES) {
            AppCompatDelegate.MODE_NIGHT_NO
        } else {
            AppCompatDelegate.MODE_NIGHT_YES
        }
        getSharedPreferences(PREFS_THEME, MODE_PRIVATE).edit().putInt(KEY_NIGHT_MODE, newMode).apply()
        AppCompatDelegate.setDefaultNightMode(newMode)
    }

    // ---------------------------------------------------------------------
    // Meniu (Export TXT / PDF, comutare temă)
    // ---------------------------------------------------------------------

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_export_txt -> {
                createTxtLauncher.launch(timestampedName("txt"))
                true
            }
            R.id.action_export_pdf -> {
                createPdfLauncher.launch(timestampedName("pdf"))
                true
            }
            R.id.action_toggle_theme -> {
                toggleTheme()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    // ---------------------------------------------------------------------
    // Ciclul de viață — salvare automată la fiecare pauză/oprire, ca plasă de
    // siguranță împotriva închiderii accidentale a aplicației.
    // ---------------------------------------------------------------------

    override fun onPause() {
        super.onPause()
        store.saveSync(transcriptEdit.text.toString())
    }

    override fun onStop() {
        super.onStop()
        store.saveSync(transcriptEdit.text.toString())
    }

    override fun onDestroy() {
        engine?.release()
        super.onDestroy()
    }

    companion object {
        const val PREFS_THEME = "vocero_theme"
        const val KEY_NIGHT_MODE = "night_mode"
    }
}
