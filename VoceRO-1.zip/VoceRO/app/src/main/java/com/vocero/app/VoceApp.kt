package com.vocero.app

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate

/**
 * Clasa Application. Singurul ei rol este să restaureze, la fiecare pornire a
 * aplicației, preferința de temă (luminoasă/întunecată) salvată de utilizator
 * din meniul principal. Dacă nu există nicio preferință salvată, se respectă
 * tema sistemului (MODE_NIGHT_FOLLOW_SYSTEM).
 */
class VoceApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val prefs = getSharedPreferences(MainActivity.PREFS_THEME, MODE_PRIVATE)
        val savedMode = prefs.getInt(MainActivity.KEY_NIGHT_MODE, AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        AppCompatDelegate.setDefaultNightMode(savedMode)
    }
}
