package com.vocero.app.engine

import android.content.Context
import java.io.File
import java.io.IOException

/**
 * whisper.cpp are nevoie de o cale reală pe disc pentru fișierul model
 * (nu poate citi direct din assets/, care e împachetat în APK). La prima
 * rulare, copiem modelul din assets/models/ în stocarea internă a aplicației
 * (context.filesDir) — o singură dată; la rulările următoare, folosim direct
 * fișierul deja copiat.
 */
object ModelManager {

    // Schimbă această constantă dacă folosești alt model, de exemplu:
    // "models/ggml-base.bin" (mai precis, dar mai lent) în loc de "ggml-tiny.bin".
    private const val ASSET_MODEL_PATH = "models/ggml-tiny.bin"
    private const val MODEL_FILENAME = "ggml-tiny.bin"

    /** Întoarce calea absolută către model, sau null dacă modelul nu a fost găsit în assets. */
    fun ensureModel(context: Context): String? {
        val outFile = File(context.filesDir, MODEL_FILENAME)
        if (outFile.exists() && outFile.length() > 0L) {
            return outFile.absolutePath
        }

        return try {
            context.assets.open(ASSET_MODEL_PATH).use { input ->
                outFile.outputStream().use { output -> input.copyTo(output) }
            }
            outFile.absolutePath
        } catch (e: IOException) {
            // Cel mai probabil modelul nu a fost pus în app/src/main/assets/models/
            // înainte de compilare — vezi README.md.
            null
        }
    }
}
