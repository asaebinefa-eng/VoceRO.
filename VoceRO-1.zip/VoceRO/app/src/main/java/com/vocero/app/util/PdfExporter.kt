package com.vocero.app.util

import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import java.io.OutputStream

/**
 * Generează un PDF simplu, paginat, din textul transcris — folosind exclusiv
 * android.graphics.pdf.PdfDocument (parte din platforma Android, nicio
 * bibliotecă externă, nicio conexiune la internet).
 */
object PdfExporter {

    private const val PAGE_WIDTH = 595   // A4 la 72dpi
    private const val PAGE_HEIGHT = 842
    private const val MARGIN = 40f
    private const val TEXT_SIZE = 12f

    fun createPdf(text: String, outputStream: OutputStream) {
        val document = PdfDocument()
        val paint = Paint().apply {
            textSize = TEXT_SIZE
            color = Color.BLACK
            isAntiAlias = true
        }
        val lineHeight = paint.fontSpacing
        val lines = wrapText(text, paint, PAGE_WIDTH - MARGIN * 2)

        var index = 0
        var pageNumber = 1
        do {
            val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
            val page = document.startPage(pageInfo)
            val canvas = page.canvas
            var y = MARGIN + lineHeight
            while (index < lines.size && y <= PAGE_HEIGHT - MARGIN) {
                canvas.drawText(lines[index], MARGIN, y, paint)
                y += lineHeight
                index++
            }
            document.finishPage(page)
            pageNumber++
        } while (index < lines.size)

        document.writeTo(outputStream)
        document.close()
    }

    private fun wrapText(text: String, paint: Paint, maxWidth: Float): List<String> {
        val result = mutableListOf<String>()
        val paragraphs = if (text.isEmpty()) listOf("") else text.split("\n")
        for (paragraph in paragraphs) {
            if (paragraph.isEmpty()) {
                result.add("")
                continue
            }
            var current = StringBuilder()
            for (word in paragraph.split(" ")) {
                val candidate = if (current.isEmpty()) word else "$current $word"
                if (paint.measureText(candidate) > maxWidth && current.isNotEmpty()) {
                    result.add(current.toString())
                    current = StringBuilder(word)
                } else {
                    current = StringBuilder(candidate)
                }
            }
            result.add(current.toString())
        }
        return result
    }
}
