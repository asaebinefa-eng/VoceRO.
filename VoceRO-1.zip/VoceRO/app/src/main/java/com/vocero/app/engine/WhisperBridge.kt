package com.vocero.app.engine

/**
 * Punte JNI către motorul nativ whisper.cpp.
 *
 * Codul C++ corespunzător acestor funcții se află în
 * app/src/main/cpp/jni_bridge.cpp și trebuie compilat împreună cu sursele
 * oficiale whisper.cpp (vezi README.md, secțiunea "Instalarea motorului de
 * recunoaștere vocală", pentru pașii obligatorii înainte de compilare).
 */
object WhisperBridge {
    init {
        System.loadLibrary("vocero_whisper_jni")
    }

    /** Încarcă modelul de pe disc; întoarce un pointer nativ (0 = eșec). */
    external fun initContext(modelPath: String): Long

    /** Eliberează contextul nativ. */
    external fun freeContext(contextPtr: Long)

    /**
     * Rulează Whisper pe un buffer audio (mono, 16 kHz, valori float în [-1, 1]).
     *
     * @param prompt textul deja confirmat, folosit ca "initial_prompt" pentru
     *   continuitate între segmente (Whisper ține cont de context astfel).
     */
    external fun transcribe(
        contextPtr: Long,
        audio: FloatArray,
        numThreads: Int,
        language: String,
        prompt: String
    ): String
}
