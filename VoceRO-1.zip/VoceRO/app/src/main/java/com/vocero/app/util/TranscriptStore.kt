package com.vocero.app.util

import android.content.Context

/**
 * Persistă transcrierea curentă în SharedPreferences, astfel încât textul să
 * nu se piardă dacă aplicația este închisă accidental (de utilizator, de
 * sistem la lipsă de memorie, etc). Se reîncarcă automat la următoarea
 * deschidere a aplicației.
 */
class TranscriptStore(context: Context) {
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /** Salvare rapidă (asincronă) — folosită după fiecare segment recunoscut. */
    fun save(text: String) {
        prefs.edit().putString(KEY_TEXT, text).apply()
    }

    /**
     * Salvare sincronă (blocantă, dar rapidă) — folosită explicit în
     * onPause()/onStop(), ca plasă de siguranță chiar dacă procesul este
     * terminat imediat după aceea de sistemul de operare.
     */
    fun saveSync(text: String) {
        prefs.edit().putString(KEY_TEXT, text).commit()
    }

    fun load(): String = prefs.getString(KEY_TEXT, "") ?: ""

    companion object {
        private const val PREFS_NAME = "vocero_transcript"
        private const val KEY_TEXT = "text"
    }
}
