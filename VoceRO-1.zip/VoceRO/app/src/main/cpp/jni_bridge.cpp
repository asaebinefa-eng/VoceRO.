// jni_bridge.cpp
//
// Aceasta este singura bucată de cod nativ scrisă special pentru VoceRO.
// Ea NU reimplementează motorul de recunoaștere vocală — apelează doar
// funcțiile publice, stabile, ale bibliotecii whisper.cpp (declarate în
// whisper.h, parte din clona pe care ai adus-o în whispercpp_src/).
//
// Corespunde declarațiilor "external fun" din
// app/src/main/java/com/vocero/app/engine/WhisperBridge.kt

#include <jni.h>
#include <string>
#include <cstring>
#include <android/log.h>
#include "whisper.h"

#define LOG_TAG "VoceRO-Whisper"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

extern "C"
JNIEXPORT jlong JNICALL
Java_com_vocero_app_engine_WhisperBridge_initContext(JNIEnv *env, jobject /*thiz*/, jstring modelPath) {
    const char *path = env->GetStringUTFChars(modelPath, nullptr);
    LOGI("Se incarca modelul din: %s", path);

    struct whisper_context_params cparams = whisper_context_default_params();
    cparams.use_gpu = false; // CPU only — compatibilitate maximă pe Huawei/EMUI

    struct whisper_context *ctx = whisper_init_from_file_with_params(path, cparams);
    env->ReleaseStringUTFChars(modelPath, path);

    if (ctx == nullptr) {
        LOGE("Nu am putut incarca modelul Whisper.");
        return 0;
    }
    return reinterpret_cast<jlong>(ctx);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_vocero_app_engine_WhisperBridge_freeContext(JNIEnv * /*env*/, jobject /*thiz*/, jlong ctxPtr) {
    if (ctxPtr == 0) return;
    auto *ctx = reinterpret_cast<struct whisper_context *>(ctxPtr);
    whisper_free(ctx);
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_vocero_app_engine_WhisperBridge_transcribe(JNIEnv *env, jobject /*thiz*/,
                                                     jlong ctxPtr,
                                                     jfloatArray audio,
                                                     jint numThreads,
                                                     jstring language,
                                                     jstring prompt) {
    if (ctxPtr == 0) {
        return env->NewStringUTF("");
    }
    auto *ctx = reinterpret_cast<struct whisper_context *>(ctxPtr);

    jsize len = env->GetArrayLength(audio);
    jfloat *audioData = env->GetFloatArrayElements(audio, nullptr);

    const char *langChars = env->GetStringUTFChars(language, nullptr);
    const char *promptChars = env->GetStringUTFChars(prompt, nullptr);

    whisper_full_params params = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    params.print_progress   = false;
    params.print_special    = false;
    params.print_realtime   = false;
    params.print_timestamps = false;
    params.translate        = false;   // vrem română -> română, nu traducere în engleză
    params.single_segment   = true;    // segmentele scurte, live, nu au nevoie de mai multe fragmente
    params.no_context        = false;
    params.suppress_blank    = true;
    params.language          = langChars;
    params.n_threads         = numThreads > 0 ? numThreads : 4;

    if (promptChars != nullptr && std::strlen(promptChars) > 0) {
        params.initial_prompt = promptChars; // continuitate cu ce s-a transcris deja
    }

    std::string result;
    if (whisper_full(ctx, params, audioData, (int) len) == 0) {
        const int n = whisper_full_n_segments(ctx);
        for (int i = 0; i < n; i++) {
            const char *seg = whisper_full_get_segment_text(ctx, i);
            if (seg != nullptr) {
                result += seg;
            }
        }
    } else {
        LOGE("whisper_full a esuat");
    }

    env->ReleaseFloatArrayElements(audio, audioData, JNI_ABORT);
    env->ReleaseStringUTFChars(language, langChars);
    env->ReleaseStringUTFChars(prompt, promptChars);

    return env->NewStringUTF(result.c_str());
}
