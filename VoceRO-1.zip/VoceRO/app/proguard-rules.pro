# Reguli ProGuard/R8 specifice aplicației VoceRO.
# minifyEnabled este dezactivat implicit (vezi app/build.gradle), deci acest fișier
# nu este critic acum, dar este referit de configurația "release" și trebuie să existe.

# Păstrează metodele native (JNI) apelate din WhisperBridge.kt
-keepclasseswithmembernames class * {
    native <methods>;
}
